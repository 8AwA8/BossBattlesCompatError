﻿using System;
using StardewModdingAPI;

namespace BossBattles
{
	// Token: 0x02000004 RID: 4
	public class BossBattlesEntry : Mod
	{
		// Token: 0x06000003 RID: 3 RVA: 0x00002050 File Offset: 0x00000250
		public override void Entry(IModHelper helper)
		{
		}
	}
}
