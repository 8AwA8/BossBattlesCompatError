﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyVersion("1.0.6.0")]
[assembly: InternalsVisibleTo("BossBattles.Test")]
[assembly: AssemblyCompany("BossBattles")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.6.0")]
[assembly: AssemblyInformationalVersion("1.0.6")]
[assembly: AssemblyProduct("BossBattles")]
[assembly: AssemblyTitle("BossBattles")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
